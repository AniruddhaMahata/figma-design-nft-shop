import React from 'react'

const tiers = [
  {
    name: "Starter",
    price: "Free",
    features: ["1 page", "Basic styles", "Email support"]
  },
  {
    name: "Pro",
    price: "₹499",
    highlight: true,
    features: ["Up to 5 pages", "Advanced styles", "Priority support"]
  },
  {
    name: "Team",
    price: "₹1499",
    features: ["Unlimited pages", "Design tokens", "Slack support"]
  },
]

export default function Pricing() {
  return (
    <section id="pricing" className="py-16 md:py-24 bg-muted/60 border-y border-border">
      <div className="container-section">
        <div className="max-w-2xl">
          <h2 className="text-3xl md:text-4xl font-extrabold">Pricing</h2>
          <p className="mt-3 text-gray-600">Scale as you grow.</p>
        </div>

        <div className="mt-10 grid md:grid-cols-3 gap-6">
          {tiers.map(t => (
            <div key={t.name} className={`card p-6 ${t.highlight ? 'ring-2 ring-primary' : ''}`}>
              <div className="flex items-baseline justify-between">
                <h3 className="font-semibold text-lg">{t.name}</h3>
                <div className="text-2xl font-extrabold">{t.price}</div>
              </div>
              <ul className="mt-4 space-y-2 text-sm text-gray-700 list-disc list-inside">
                {t.features.map(f => <li key={f}>{f}</li>)}
              </ul>
              <a href="#cta" className={`mt-6 w-full text-center ${t.highlight ? 'btn-primary' : 'btn-secondary'}`}>Choose {t.name}</a>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
