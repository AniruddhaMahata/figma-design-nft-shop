import React from 'react'
import Logo from '../assets/logo.svg'

export default function Navbar() {
  const [open, setOpen] = React.useState(false)

  return (
    <header className="sticky top-0 z-40 bg-background/80 border-b border-border backdrop-blur">
      <div className="container-section flex items-center justify-between h-16">
        <a href="#" className="flex items-center gap-2">
          <img src={Logo} alt="Logo" className="h-8 w-auto" />
        </a>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <a className="hover:opacity-80" href="#features">Features</a>
          <a className="hover:opacity-80" href="#pricing">Pricing</a>
          <a className="hover:opacity-80" href="#testimonials">Testimonials</a>
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <a href="#cta" className="btn-secondary">Learn more</a>
          <a href="#cta" className="btn-primary">Get started</a>
        </div>

        <button
          className="md:hidden inline-flex items-center justify-center rounded-xl border border-border p-2"
          onClick={() => setOpen(v => !v)}
          aria-label="Toggle menu"
        >
          <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M4 6h16M4 12h16M4 18h16" strokeLinecap="round"/>
          </svg>
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border p-4 space-y-3 bg-background">
          <a className="block" href="#features" onClick={() => setOpen(false)}>Features</a>
          <a className="block" href="#pricing" onClick={() => setOpen(false)}>Pricing</a>
          <a className="block" href="#testimonials" onClick={() => setOpen(false)}>Testimonials</a>
          <a className="btn-primary mt-2 inline-flex" href="#cta" onClick={() => setOpen(false)}>Get started</a>
        </div>
      )}
    </header>
  )
}
