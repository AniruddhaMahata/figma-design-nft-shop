import React from 'react'
import Placeholder from '../assets/placeholder-2.svg'

const features = [
  { title: "Design Tokens", desc: "Colors, spacing, typography wired via CSS variables for easy theming.", icon: "🎨" },
  { title: "Responsive Grid", desc: "Mobile-first layout with semantic HTML and Tailwind utilities.", icon: "📱" },
  { title: "Interactive UI", desc: "Accessible focus states, hover, and motion where it adds value.", icon: "⚡" },
  { title: "Clean Code", desc: "Componentized, readable, and production-ready structure.", icon: "🧼" },
  { title: "Performance", desc: "Lazy-loaded images and optimized assets through Vite.", icon: "🚀" },
  { title: "Deploy Ready", desc: "Vercel config and README included for one-click deploy.", icon: "☁️" },
]

export default function Features() {
  return (
    <section id="features" className="py-16 md:py-24 bg-muted/60 border-y border-border">
      <div className="container-section">
        <div className="max-w-2xl">
          <h2 className="text-3xl md:text-4xl font-extrabold">Features</h2>
          <p className="mt-3 text-gray-600">Everything you need to mirror the Figma faithfully.</p>
        </div>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div key={f.title} className="card p-6">
              <div className="text-2xl">{f.icon}</div>
              <h3 className="mt-3 font-semibold text-lg">{f.title}</h3>
              <p className="text-gray-600 text-sm mt-1">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12">
          <img src={Placeholder} alt="Feature mock" className="w-full rounded-2xl border border-border shadow-soft" />
        </div>
      </div>
    </section>
  )
}
