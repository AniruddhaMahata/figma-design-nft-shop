import React from 'react'

export default function CTA() {
  return (
    <section id="cta" className="py-16 md:py-24">
      <div className="container-section card p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-2xl md:text-3xl font-extrabold">Ready to see it live?</h3>
          <p className="text-gray-600 mt-2">Hook up your Figma styles and deploy in minutes.</p>
        </div>
        <div className="flex items-center gap-3">
          <a href="#" className="btn-secondary">Learn more</a>
          <a href="#" className="btn-primary">Get started</a>
        </div>
      </div>
    </section>
  )
}
