import React from 'react'

const data = [
  { name: "Aaliyah Verma", role: "Product Designer", quote: "The handoff fidelity was perfect. Saved us days of tweaks." },
  { name: "Rahul Singh", role: "Frontend Lead", quote: "Clean, accessible, and fast. Exactly what we expect." },
  { name: "Priya Iyer", role: "PM", quote: "Responsive across breakpoints with zero visual regressions." },
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-16 md:py-24">
      <div className="container-section">
        <div className="max-w-2xl">
          <h2 className="text-3xl md:text-4xl font-extrabold">What folks say</h2>
          <p className="mt-3 text-gray-600">Quality that teams notice right away.</p>
        </div>

        <div className="mt-10 grid md:grid-cols-3 gap-6">
          {data.map((t) => (
            <figure key={t.name} className="card p-6">
              <blockquote className="text-gray-700">&ldquo;{t.quote}&rdquo;</blockquote>
              <figcaption className="mt-4 text-sm">
                <div className="font-semibold">{t.name}</div>
                <div className="text-gray-500">{t.role}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
