import React from 'react'
import { motion } from 'framer-motion'
import Placeholder from '../assets/placeholder-1.svg'

export default function Hero() {
  return (
    <section className="container-section grid lg:grid-cols-2 gap-10 py-16 lg:py-24 items-center">
      <div>
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-5xl font-extrabold tracking-tight leading-tight"
        >
          Build delightful UIs — fast.
        </motion.h1>
        <p className="mt-4 text-lg text-gray-600">
          Pixel-perfect, accessible, and responsive components implemented from your Figma design.
        </p>
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <a href="#cta" className="btn-primary">Get started</a>
          <a href="#features" className="btn-secondary">See features</a>
        </div>

        <div className="mt-8 grid grid-cols-3 gap-4 text-center">
          <div className="card p-4">
            <div className="text-2xl font-bold">100%</div>
            <div className="text-sm text-gray-600">Responsive</div>
          </div>
          <div className="card p-4">
            <div className="text-2xl font-bold">A11y</div>
            <div className="text-sm text-gray-600">Accessible</div>
          </div>
          <div className="card p-4">
            <div className="text-2xl font-bold">&lt;60ms</div>
            <div className="text-sm text-gray-600">Interactions</div>
          </div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.6 }}
        className="relative"
      >
        <img alt="Hero illustration" src={Placeholder} className="w-full rounded-2xl shadow-soft border border-border" />
        <div className="absolute inset-x-0 -bottom-6 mx-auto w-11/12 h-6 bg-black/5 blur-2xl rounded-full" />
      </motion.div>
    </section>
  )
}
